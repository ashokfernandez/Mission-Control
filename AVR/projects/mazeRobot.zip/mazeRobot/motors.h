/** @file   motors.c
    @author A. Z. Fernandez
    @date   15 July 2012
    @brief  Routines to set PWM outputs and switching for an L293DNE H-bridge
            connected to two DC motors
*/

#ifndef MOTORS_H
#define MOTORS_H

/**********************************************************************
 * ------------------------PUBLIC FUNCTIONS----------------------------
 * *******************************************************************/

/** Initialises the PWM outputs and pins to send control signals
 *  to the H-bridge. */
void motors_init(void);

/** Sets both motors to drive forwards with a direction given as a number
 *  between -100 and 100. If direction is given as -100 the robot will go
 *  full speed to the left and vice-versa. Direction set to 0 will give
 *  equal power to both motors.
 *      @param percentage direction with -100 being 100% left and
 *             100 being 100% right (0 is straight ahead) */
void motors_go(int16_t direction);

/** Stops the motors given a parameter of how to stop. Valid arguments are
 *  FREE_RUNNING or BRAKE */
void motors_stop(void);

#endif /* MOTORS_H */
