/** @file   motors.c
    @author A. Z. Fernandez
    @date   15 July 2012
    @brief  Routines to set PWM outputs and switching for an L293DNE H-bridge
            connected to two DC motors
*/

/**********************************************************************
 * -------------------------DEPENDENCIES------------------------------
 * *******************************************************************/

/** Include modules */
#include "system.h" // System definitions and bit macros
#include "motors.h" // Function declarations
#include "pwm.h" // PWM module

/** Include built-in AVR libraries */
#include <avr/io.h> // Pin and register definitions
#include <avr/delay.h> // _delay_ms()


/**********************************************************************
 * ---------------------------DEFINITIONS------------------------------
 * *******************************************************************/

/* PWM channels for the motors */
#define LEFT_MOTOR_PWM PWM_CHANNEL_2
#define RIGHT_MOTOR_PWM PWM_CHANNEL_1

/* Max and min duty cycles to stop the motors from stalling and drawing
 * too much current */
#define MIN_PWM_DUTY 60
#define MAX_PWM_DUTY 180

/* Base speed for the robot to drive forward */
#define BASE_MOTOR_SPEED MAX_PWM_DUTY

/**********************************************************************
 * -----------------------PRIVATE FUNCTIONS----------------------------
 * *******************************************************************/

/**------------FUNCTIONS TO CONTROL THE MOTOR CONTROL PINS------------*/

static inline void RIGHT_MOTOR_FORWARD(void)
{
    PORTB &= ~BIT(PB0); 
    PORTD |= BIT(PD7);
}

static inline void RIGHT_MOTOR_REVERSE(void)
{
    PORTB |= BIT(PB0); 
    PORTD &= ~BIT(PD7);
}

static inline void RIGHT_MOTOR_STOP(void)
{
    PORTB |= BIT(PB0); 
    PORTD |= BIT(PD7);
}


static inline void LEFT_MOTOR_FORWARD(void)
{ 
    PORTB |= BIT(PB3);
    PORTB &= ~BIT(PB4);
}


static inline void LEFT_MOTOR_REVERSE(void)
{ 
    PORTB &= ~BIT(PB3);
    PORTB |= BIT(PB4);
}


static inline void LEFT_MOTOR_STOP(void)
{ 
    PORTB |= BIT(PB4);
    PORTB |= BIT(PB3);
}

/** Ensures the pwm duty cycle does not exceed the specified limits
        @param duty cycle
        @return duty cycle clipped to saturation limits
*/
uint8_t dutyCycleSaturationFilter(uint8_t duty)
{
    uint8_t newDuty = duty;
    
    if(duty < MIN_PWM_DUTY)
        newDuty = MIN_PWM_DUTY;
    else if(duty > MAX_PWM_DUTY)
        newDuty = MAX_PWM_DUTY;

    return newDuty;    
}

/**********************************************************************
 * ------------------------PUBLIC FUNCTIONS----------------------------
 * *******************************************************************/

/** Initialises the PWM outputs and pins to send control signals
 *  to the H-bridge. */
void motors_init(void)
{
    /* Initialise PWM outputs and set control pins as outputs */
    pwm_init();
    DDRB |= BIT(PB0) | BIT (PB3) | BIT(PB4);
    DDRD |= BIT(PD7);    
    
    /* Initalise the motors to be off */
    pwm_setDuty(PWM_CHANNEL_1, 0);
    pwm_setDuty(PWM_CHANNEL_2, 0);
    
    RIGHT_MOTOR_STOP();
    LEFT_MOTOR_STOP();  
    
}

/** Sets both motors to drive forwards with a direction given as a number
 *  between -100 and 100. If direction is given as -100 the robot will go
 *  full speed to the left and vice-versa. Direction set to 0 will give
 *  equal power to both motors.
 *      @param percentage direction with -100 being 100% left and
 *             100 being 100% right (0 is straight ahead) */
void motors_go(int16_t direction)
{
    /* Initialise the motors to be full-speed ahead (it's a race after all!) */
    uint8_t leftMotorDuty = BASE_MOTOR_SPEED;
    uint8_t rightMotorDuty = BASE_MOTOR_SPEED;
    
    /* Scale the given direction to a value between -255 and 255 */
    /* TODO: Adapt this so it does not require float typecasting, the poor
     * little atmega8 probably isnt too happy about having to run this line :( */
    direction = (int16_t)(((float)direction / 100) * MAX_UINT8);
    
    /* Minus the scaled direction value from the duty cyles, the sign of
     * direction will take care of the ratio of the motors speed so the
     * robot will turn */
    if(direction < 0)
        leftMotorDuty -= direction;
    else
        rightMotorDuty -= direction;
    
    /* Ensure the duty cycle is within specified limits */
    leftMotorDuty = dutyCycleSaturationFilter(leftMotorDuty);
    rightMotorDuty = dutyCycleSaturationFilter(rightMotorDuty);
    
    /* Set the motors duty cycles and ensure the control pins are set to
     * drive forward */
    pwm_setDuty(LEFT_MOTOR_PWM, leftMotorDuty);
    pwm_setDuty(RIGHT_MOTOR_PWM, rightMotorDuty);
    
    RIGHT_MOTOR_FORWARD();
    LEFT_MOTOR_FORWARD();
}

/** Stops the motors */
void motors_stop(void)
{
    /* As the duty cycle as to be respecified to get the motors to start
     * again it doesnt matter at this stage and can be left as is */
    RIGHT_MOTOR_STOP();
    LEFT_MOTOR_STOP();
}
