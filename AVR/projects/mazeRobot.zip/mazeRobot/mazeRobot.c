/** @file   mazeRobot.c
    @author A. Z. Fernandez
    @date   22 June 2012
    @brief  Main file for the maze solving robot for the ENEL300 robot  
*/

/**********************************************************************
 * -------------------------DEPENDENCIES------------------------------
 * *******************************************************************/

/** Include modules */
#include "system.h" // System definitions and bit macros
#include "debugLed.h" // Debug LED macros
#include "lineSensors.h" // Line Sensors module
#include "motors.h" // Motor Control module

#include "lcd.h"
#include "lcdText.h"

/** Include builtin AVR libraries */
#include <avr/io.h> // Pin and register definitions
#include <util/delay.h>

/**********************************************************************
 * ---------------------------DEFINITIONS------------------------------
 * *******************************************************************/

#define BLACK_CUTOFF 140
#define GREY_CUTOFF 370

/**********************************************************************
 * -------------------------FILE VARIABLES-----------------------------
 * *******************************************************************/
 
static sensors_t IR_sensors = {0, 0};


/**********************************************************************
 * -----------------------PRIVATE FUNCTIONS----------------------------
 * *******************************************************************/

/** Flashes a debug LED to let the user know the micro has been reset */
void resetBlink(void)
{
    int i = 0;
    
    for(i = 0; i < 5; i++)
    {
        DEBUG_LED_1_ON;
        _delay_ms(75);
        DEBUG_LED_1_OFF;
        _delay_ms(75);
    }
}

void updateDisplay(void)
{
    lcd_clrscr();
    lcdText_printf(1, "%i, %i", IR_sensors.middle, IR_sensors.left);
    
    lcd_gotoxy(0, 2);
    if(IR_sensors.middle < BLACK_CUTOFF)
        lcd_puts("Black");
    else if(IR_sensors.middle < GREY_CUTOFF)
        lcd_puts("Grey");
    else
        lcd_puts("White");
    
    lcd_gotoxy(6,2);
    
    if(IR_sensors.left < BLACK_CUTOFF)
        lcd_puts("Black");
    else if(IR_sensors.left < GREY_CUTOFF)
        lcd_puts("Grey");
    else
        lcd_puts("White");
}
/**********************************************************************
 * -------------------*****   MAIN   *****---------------------------
 * *******************************************************************/

int main(void)
{
    /* Flash the debug light upon reset */
    DEBUG_LED_INIT;
    resetBlink();
    
    int16_t direction = 0;
    
    /* Initialise components */    
    lcd_init(LCD_DISP_ON);
    lineSensors_init();
    motors_init();
    
    while(1) // Loop forever
    {
    lineSensors_read(&IR_sensors);
    updateDisplay();
      
    /* TODO ----------------------
     * CONTROL ALGORITHM GOES HERE */
    //motors_go((uint8_t)(IR_sensors.left - IR_sensors.middle));
    
    _delay_ms(50);
    }

}
